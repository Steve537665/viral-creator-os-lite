const state = {
  data: {},
  activeTool: "dashboard",
  favorites: JSON.parse(localStorage.getItem("vcos_favorites") || "[]")
};

const options = {
  platform: ["Instagram", "TikTok", "LinkedIn", "YouTube Shorts"],
  goal: ["views", "comments", "followers", "sales", "leads"],
  tone: ["bold", "educational", "professional", "storytelling", "controversial"],
  length: ["15s", "30s", "60s"],
  style: ["talking head", "AI avatar", "educational", "storytelling", "product promo"]
};

const dataFiles = {
  hooks: "data/hooks.json",
  captions: "data/captions.json",
  ctas: "data/ctas.json",
  scripts: "data/scripts.json",
  ideas: "data/content-ideas.json",
  bios: "data/bios.json"
};

const $ = (selector, parent = document) => parent.querySelector(selector);
const $$ = (selector, parent = document) => [...parent.querySelectorAll(selector)];

document.addEventListener("DOMContentLoaded", init);

async function init() {
  populateSelects();
  bindNavigation();
  bindForms();
  bindGlobalActions();
  await loadData();
  renderFavorites();
  showToast("Viral Creator OS Lite is ready.");
}

async function loadData() {
  try {
    const entries = await Promise.all(
      Object.entries(dataFiles).map(async ([key, path]) => {
        const response = await fetch(path);
        if (!response.ok) throw new Error(`Could not load ${path}`);
        return [key, await response.json()];
      })
    );
    state.data = Object.fromEntries(entries);
  } catch (error) {
    showToast("Open this app through a local server so JSON files can load.");
    console.error(error);
  }
}

function populateSelects() {
  $$("select").forEach((select) => {
    const name = select.name;
    if (!options[name]) return;
    select.innerHTML = options[name]
      .map((option) => `<option value="${escapeHtml(option)}">${escapeHtml(titleCase(option))}</option>`)
      .join("");
  });
}

function bindNavigation() {
  $$("[data-tool], [data-tool-jump]").forEach((element) => {
    element.addEventListener("click", () => {
      const tool = element.dataset.tool || element.dataset.toolJump;
      activatePanel(tool);
      document.body.classList.remove("nav-open");
    });
  });

  $(".menu-toggle").addEventListener("click", () => {
    document.body.classList.toggle("nav-open");
  });
}

function bindForms() {
  $$("[data-generator]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = Object.fromEntries(new FormData(form).entries());
      const generator = form.dataset.generator;
      const output = generators[generator](formData);
      renderResults(`${generator}Results`, output);
    });
  });
}

function bindGlobalActions() {
  $("#exportAll").addEventListener("click", exportFavorites);
  $("#clearFavorites").addEventListener("click", () => {
    if (!state.favorites.length) {
      showToast("No favorites to clear.");
      return;
    }
    state.favorites = [];
    persistFavorites();
    renderFavorites();
    showToast("Favorites cleared.");
  });
}

function activatePanel(tool) {
  state.activeTool = tool;
  $$("[data-panel]").forEach((panel) => {
    panel.classList.toggle("hidden", panel.dataset.panel !== tool);
  });
  $$(".nav-item").forEach((item) => {
    item.classList.toggle("active", item.dataset.tool === tool);
  });
  window.scrollTo({ top: 0, behavior: "smooth" });
}

const generators = {
  hooks({ niche, platform, goal, tone }) {
    const hookData = state.data.hooks;
    const pool = shuffle([...hookData.base, ...(hookData.styles[tone] || [])]);
    const context = { niche, platform, goal, tone };
    const hooks = pool.slice(0, 10).map((template) => fill(template, context));
    const alternatives = shuffle(hookData.alternatives).slice(0, 3);

    return [
      {
        title: "10 Viral Hooks",
        content: hooks.map((hook, index) => `${index + 1}. ${hook}`).join("\n")
      },
      {
        title: "3 Alternative Hook Styles",
        content: alternatives.map((item, index) => `${index + 1}. ${item}`).join("\n")
      }
    ];
  },

  captions({ topic, platform, goal, tone }) {
    const captionData = state.data.captions;
    const ctas = state.data.ctas;
    const context = { topic, platform, goal, tone };
    const shortCaption = fill(pick(captionData.short), context);
    const longCaption = fill(pick(captionData.long), context);

    return [
      { title: "Short Caption", content: shortCaption },
      { title: "Long Caption", content: longCaption },
      { title: "CTA", content: contextualCta(goal, ctas.primary) },
      { title: "Comment CTA", content: contextualCta(goal, ctas.comment) },
      { title: "DM CTA", content: contextualCta(goal, ctas.dm) },
      { title: "Save / Share CTA", content: contextualCta(goal, ctas.saveShare) },
      { title: "Hashtags", content: pick(captionData.hashtags) }
    ];
  },

  scripts({ topic, length, style }) {
    const scriptData = state.data.scripts;
    const framework = scriptData.frameworks[style] || scriptData.frameworks.educational;
    const context = { topic, length, style };
    const hook = fill(framework.hook, context);
    const body = fill(framework.body, context);
    const cta = framework.cta;
    const subtitle = [hook, body, cta].join("\n");

    return [
      { title: "Hook", content: hook },
      { title: "Body", content: `${body}\n\nLength note: ${scriptData.lengthGuides[length]}` },
      { title: "CTA", content: cta },
      { title: "Subtitle Version", content: subtitle },
      { title: "Cover Text Suggestion", content: pick(scriptData.covers) }
    ];
  },

  ideas({ niche, platform, goal }) {
    const ideasData = state.data.ideas;
    const context = { niche, platform, goal };
    const ideas = shuffle(ideasData.ideas).slice(0, 20).map((idea) => fill(idea, context));
    const carousels = shuffle(ideasData.carousels).slice(0, 5).map((idea) => fill(idea, context));
    const videos = shuffle(ideasData.videos).slice(0, 5).map((idea) => fill(idea, context));

    return [
      {
        title: "20 Content Ideas",
        content: ideas.map((idea, index) => `${index + 1}. ${idea}`).join("\n")
      },
      {
        title: "5 Carousel Ideas",
        content: carousels.map((idea, index) => `${index + 1}. ${idea}`).join("\n")
      },
      {
        title: "5 Short-Form Video Ideas",
        content: videos.map((idea, index) => `${index + 1}. ${idea}`).join("\n")
      }
    ];
  },

  bios({ name, role, audience, offer, tone }) {
    const bioData = state.data.bios;
    const context = { name, role, audience, offer, tone };
    return [
      { title: "Instagram Bio", content: fill(pick(bioData.instagram), context) },
      { title: "TikTok Bio", content: fill(pick(bioData.tiktok), context) },
      { title: "LinkedIn Headline", content: fill(pick(bioData.linkedin), context) },
      { title: "Short Personal Brand Statement", content: fill(pick(bioData.statement), context) }
    ];
  }
};

function renderResults(containerId, results) {
  const container = $(`#${containerId}`);
  container.innerHTML = results.map((result) => resultCard(result)).join("");
  bindResultActions(container, results);
}

function resultCard(result, favoriteIndex = null) {
  const deleteButton =
    favoriteIndex === null
      ? ""
      : `<button class="delete-button" data-delete="${favoriteIndex}" type="button">Delete</button>`;

  return `
    <article class="result-card">
      <div class="result-header">
        <h3>${escapeHtml(result.title)}</h3>
        <div class="result-actions">
          <button class="copy-button" data-copy type="button">Copy</button>
          <button class="favorite-button" data-favorite type="button">Save</button>
          <button class="export-button" data-export type="button">Export .txt</button>
          ${deleteButton}
        </div>
      </div>
      <div class="result-content">${escapeHtml(result.content)}</div>
    </article>
  `;
}

function bindResultActions(container, results) {
  $$(".result-card", container).forEach((card, index) => {
    const result = results[index];
    $("[data-copy]", card).addEventListener("click", () => copyText(formatResult(result)));
    $("[data-favorite]", card).addEventListener("click", () => saveFavorite(result));
    $("[data-export]", card).addEventListener("click", () => exportText(formatResult(result), slug(result.title)));
  });
}

function renderFavorites() {
  const container = $("#favoritesResults");
  if (!state.favorites.length) {
    container.innerHTML = `<article class="result-card"><p>No favorites saved yet.</p></article>`;
    return;
  }

  container.innerHTML = state.favorites
    .map((favorite, index) => resultCard(favorite, index))
    .join("");

  $$(".result-card", container).forEach((card, index) => {
    const result = state.favorites[index];
    $("[data-copy]", card).addEventListener("click", () => copyText(formatResult(result)));
    $("[data-favorite]", card).addEventListener("click", () => showToast("Already saved."));
    $("[data-export]", card).addEventListener("click", () => exportText(formatResult(result), slug(result.title)));
    $("[data-delete]", card).addEventListener("click", () => {
      state.favorites.splice(index, 1);
      persistFavorites();
      renderFavorites();
      showToast("Favorite removed.");
    });
  });
}

function saveFavorite(result) {
  const favorite = {
    ...result,
    savedAt: new Date().toISOString()
  };
  state.favorites.unshift(favorite);
  state.favorites = state.favorites.slice(0, 80);
  persistFavorites();
  renderFavorites();
  showToast("Saved to favorites.");
}

function persistFavorites() {
  localStorage.setItem("vcos_favorites", JSON.stringify(state.favorites));
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    showToast("Copied.");
  } catch {
    const textarea = document.createElement("textarea");
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand("copy");
    textarea.remove();
    showToast("Copied.");
  }
}

function exportFavorites() {
  if (!state.favorites.length) {
    showToast("Save favorites before exporting.");
    return;
  }
  const text = state.favorites.map(formatResult).join("\n\n---\n\n");
  exportText(text, "viral-creator-os-lite-favorites");
}

function exportText(text, filename) {
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${filename}.txt`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  showToast("Export started.");
}

function formatResult(result) {
  return `${result.title}\n\n${result.content}`;
}

function contextualCta(goal, pool) {
  const goalMap = {
    comments: pool.find((item) => item.toLowerCase().includes("comment")),
    followers: pool.find((item) => item.toLowerCase().includes("follow")),
    sales: pool.find((item) => item.toLowerCase().includes("bio")) || pick(pool),
    leads: pool.find((item) => item.toLowerCase().includes("dm")) || pick(pool),
    views: pool.find((item) => item.toLowerCase().includes("share")) || pick(pool)
  };
  return goalMap[goal] || pick(pool);
}

function fill(template, values) {
  return template.replace(/\{(\w+)\}/g, (_, key) => values[key] || "");
}

function pick(items) {
  return items[Math.floor(Math.random() * items.length)];
}

function shuffle(items) {
  return [...items].sort(() => Math.random() - 0.5);
}

function titleCase(value) {
  return value.replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function slug(value) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => {
    const map = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;"
    };
    return map[character];
  });
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove("show"), 2200);
}
