# Viral Creator OS Lite

Viral Creator OS Lite is a free static browser toolkit that helps creators generate hooks, captions, CTAs, short video scripts, content ideas, and personal brand bios without a backend or paid API.

## What It Uses

- HTML
- CSS
- JavaScript
- Local JSON template files
- `localStorage` for favorites

It does not use OpenAI, Supabase, Stripe, authentication, databases, server functions, or any backend.

## Run Locally

Because the app loads local JSON files, run it through a simple static server:

```bash
cd viral-creator-os-lite
python3 -m http.server 8080
```

Then open:

```text
http://127.0.0.1:8080
```

## Deploy Free To GitHub Pages

1. Create a GitHub repository.
2. Push the contents of this folder to the repository.
3. In GitHub, open Settings > Pages.
4. Set Source to `Deploy from a branch`.
5. Choose your main branch and root folder.
6. Save and open the GitHub Pages URL after deployment finishes.

## Deploy Free To Netlify

1. Go to Netlify and create a new site.
2. Drag and drop this folder into Netlify, or connect the GitHub repository.
3. Leave the build command empty.
4. Set the publish directory to the project root.
5. Deploy.

## Deploy Free To Vercel

1. Create a new Vercel project.
2. Import the GitHub repository.
3. Leave the framework preset as `Other`.
4. Leave the build command empty.
5. Set the output directory to the project root.
6. Deploy.

## Files

- `index.html` - app layout and tool sections
- `styles.css` - premium dashboard styling
- `app.js` - client-side generator logic
- `data/hooks.json` - hook templates
- `data/captions.json` - caption templates
- `data/ctas.json` - CTA templates
- `data/scripts.json` - script templates
- `data/content-ideas.json` - content idea templates
- `data/bios.json` - personal brand bio templates
- `assets/logo.svg` - app icon

## Limitations

- Outputs are template-based, not AI-generated.
- Quality depends on the local JSON template library.
- Favorites are saved only in the current browser through `localStorage`.
- Opening `index.html` directly from the file system may block JSON loading in some browsers; use a static server.
